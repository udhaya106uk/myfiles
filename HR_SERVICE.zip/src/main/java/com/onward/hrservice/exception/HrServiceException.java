package com.onward.hrservice.exception;

public class HrServiceException extends Exception {

	private static final long serialVersionUID = 1L;

	public HrServiceException(String message) {
		super(message);
	}
}
