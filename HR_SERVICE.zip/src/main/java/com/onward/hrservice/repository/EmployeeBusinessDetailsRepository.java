package com.onward.hrservice.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.onward.hrservice.entity.EmployeeBusinessDetails;

public interface EmployeeBusinessDetailsRepository extends JpaRepository<EmployeeBusinessDetails, Integer> {
	
	public EmployeeBusinessDetails findByEmpCode(Integer empCode);
	
	@Query(value="SELECT A FROM EmployeeBusinessDetails A WHERE empbDepId =:hrpbId")
	List<EmployeeBusinessDetails> getHrpB(String hrpbId);

}
