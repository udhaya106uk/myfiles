package com.onward.hrservice.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.onward.hrservice.entity.PincodeMaster;

public interface PincodeMasterRepository extends JpaRepository<PincodeMaster, Integer> {
	
	public PincodeMaster findByPinPincode(String pincode);

}
