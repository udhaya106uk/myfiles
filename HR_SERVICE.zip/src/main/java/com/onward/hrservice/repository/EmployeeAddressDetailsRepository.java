package com.onward.hrservice.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.onward.hrservice.entity.EmployeeAddressDetails;

public interface EmployeeAddressDetailsRepository extends JpaRepository<EmployeeAddressDetails, Integer> {
	
	public EmployeeAddressDetails findByEmpCode(Integer empCode);

}
