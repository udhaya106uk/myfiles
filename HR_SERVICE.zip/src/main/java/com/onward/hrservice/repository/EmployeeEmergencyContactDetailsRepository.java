package com.onward.hrservice.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.onward.hrservice.entity.EmployeeEmergencyContactDetails;

public interface EmployeeEmergencyContactDetailsRepository extends JpaRepository<EmployeeEmergencyContactDetails, Integer> {
	
	public EmployeeEmergencyContactDetails findByEmpCode(Integer empCode);

}
