package com.onward.hrservice.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.onward.hrservice.entity.EmployeePassportDetails;

public interface EmployeePassportDetailsRepository extends JpaRepository<EmployeePassportDetails, String> {
	
	public EmployeePassportDetails findByEmpCode(Integer empCode);

}
