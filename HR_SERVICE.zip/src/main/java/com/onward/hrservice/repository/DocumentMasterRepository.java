package com.onward.hrservice.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.onward.hrservice.entity.DocumentMaster;

public interface DocumentMasterRepository extends JpaRepository<DocumentMaster, Integer> {
	
	public List<DocumentMaster> findByEmpNumber(String empNumber);
	
	@Query(value="SELECT A FROM DocumentMaster A WHERE empNumber =:empNumber and docType =:type")
	public DocumentMaster getDocumentByType(String empNumber, String type);

}
