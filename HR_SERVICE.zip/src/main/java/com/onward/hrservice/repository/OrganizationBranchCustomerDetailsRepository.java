package com.onward.hrservice.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.onward.hrservice.entity.OrganizationBranchCustomerDetails;

public interface OrganizationBranchCustomerDetailsRepository extends JpaRepository<OrganizationBranchCustomerDetails, Integer> {
	
	@Query(value="SELECT A FROM OrganizationBranchCustomerDetails A WHERE orgbcCustomer =:customerName and status ='A' ")
	public OrganizationBranchCustomerDetails findByOrgbcCustomer(String customerName);
	
	public OrganizationBranchCustomerDetails findByOrgbcCode(Integer orgCode);

}
