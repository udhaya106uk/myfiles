package com.onward.hrservice.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.onward.hrservice.entity.CustomerMaster;

public interface CustomerMasterRepository extends JpaRepository<CustomerMaster, Integer> {
	
	@Query(value="SELECT A FROM CustomerMaster A WHERE custName =:customerName and status ='A' ")
	public CustomerMaster findBycustName(String customerName);
	
	public CustomerMaster findBycustCode(Integer custCode);

}
