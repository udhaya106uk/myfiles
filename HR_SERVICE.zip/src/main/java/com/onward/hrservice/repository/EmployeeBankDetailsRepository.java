package com.onward.hrservice.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.onward.hrservice.entity.EmployeeBankDetails;

public interface EmployeeBankDetailsRepository extends JpaRepository<EmployeeBankDetails, Integer>{

	EmployeeBankDetails findByEmpCode(Integer empCode);

}
