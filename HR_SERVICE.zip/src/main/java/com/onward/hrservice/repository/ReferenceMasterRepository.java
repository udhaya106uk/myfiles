package com.onward.hrservice.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.onward.hrservice.entity.ReferenceMaster;

public interface ReferenceMasterRepository extends JpaRepository<ReferenceMaster, Integer> {
	
	@Query("SELECT A FROM ReferenceMaster A WHERE refParentCode =:id AND status='A' ORDER BY refDescription ASC")
	public List<ReferenceMaster> findByRefParentCodeOrderByRefDescriptionAsc(String id);
	
	public List<ReferenceMaster> findByRefChildOf(String id);
	
	public ReferenceMaster findByRefDescription(String desc);
	
	@Query("SELECT refDescription FROM ReferenceMaster A WHERE refCode =:code")
	public String getRefDescription(String code);
	
}
