package com.onward.hrservice.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.onward.hrservice.entity.EmployeeDetailsView;

public interface EmployeeDetailsViewRepository extends JpaRepository<EmployeeDetailsView, Integer> {
	
	@Query("SELECT A FROM EmployeeDetailsView A WHERE empCode in (:empCode)")
	List<EmployeeDetailsView> findByEmpCode(List<Integer> empCode);

}
