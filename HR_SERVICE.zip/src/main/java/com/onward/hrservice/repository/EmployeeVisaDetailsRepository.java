package com.onward.hrservice.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.onward.hrservice.entity.EmployeeVisaDetails;

public interface EmployeeVisaDetailsRepository extends JpaRepository<EmployeeVisaDetails, String> {
	
	public EmployeeVisaDetails findByEmpCode(Integer empCode);
}
