package com.onward.hrservice.exceptionhandler;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.context.request.WebRequest;

import static com.onward.hrservice.common.Utility.fail;
import com.onward.hrservice.exception.HrServiceException;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@ControllerAdvice
public class ControllerAdvisor {

	@ExceptionHandler(HrServiceException.class)
	public ResponseEntity<Object> handleRBACException(HrServiceException ex, WebRequest request) {
		log.error("Error Occurred due to ", ex);
		return new ResponseEntity<>(fail(ex.getMessage()), HttpStatus.BAD_REQUEST);
	}

	@ExceptionHandler(Exception.class)
	public ResponseEntity<Object> handleException(Exception ex, WebRequest request) {
		log.error("Error Occurred due to ", ex);
		return new ResponseEntity<>(fail(ex.getMessage()), HttpStatus.INTERNAL_SERVER_ERROR);
	}
}
