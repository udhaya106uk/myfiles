package com.onward.hrservice.entity;

import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Data;

@Data
@Entity
@Table(name = "org_branch_customer_det")
public class OrganizationBranchCustomerDetails {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="orgbc_code")
	private Integer orgbcCode;
	@Column(name="orgb_code")
	private Integer orgbCode;
	@Column(name="orgbc_customer")
	private String orgbcCustomer;
	@Column(name="orgbc_customercode")
	private String orgbcCustomercode;
	@Column(name="orgbc_state")
	private String orgbcState;
	@Column(name="orgbc_country")
	private String orgbcCountry;
	@Column(name="status")
	private String status;
	@Column(name="created_by")
	private Integer createdBy;
	@Column(name="created_on")
	private LocalDateTime createdOn;
	@Column(name="modified_by")
	private Integer modifiedBy;
	@Column(name="modified_on")
	private LocalDateTime modifiedOn;
	@Column(name="approved_by")
	private Integer approvedBy;
	@Column(name="approved_on")
	private LocalDateTime approvedOn;

}
