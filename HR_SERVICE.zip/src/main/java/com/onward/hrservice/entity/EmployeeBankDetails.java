package com.onward.hrservice.entity;

import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Data;

@Data
@Entity
@Table(name = "emp_banking_det")

public class EmployeeBankDetails {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="embk_code")
	private Integer embkCode;
	@Column(name="emp_code")
	private Integer empCode;
	@Column(name="embk_mnh_id")
	private Integer embkMnhId;
	@Column(name="embk_name_asper_bank")
	private String embkNameAsperBank;
	@Column(name="embk_bank_name")
	private String embkBankName;
	@Column(name="embk_bank_acc_no")
	private String embkBankAccNo;
	@Column(name="embk_ifsc_code")
	private String embkIfscCode;
	@Column(name="status")
	private String status;
	@Column(name="created_by")
	private Integer createdBy;
	@Column(name="created_on")
	private LocalDateTime createdOn;
	@Column(name="modified_by")
	private Integer modifiedBy;
	@Column(name="modified_on")
	private LocalDateTime modifiedOn;
	@Column(name="approved_by")
	private Integer approvedBy;
	@Column(name="approved_on")
	private LocalDateTime approvedOn;


}
