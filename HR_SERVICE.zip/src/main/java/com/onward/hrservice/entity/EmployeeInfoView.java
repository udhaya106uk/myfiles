package com.onward.hrservice.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Data;

@Data
@Entity
@Table(name = "emp_info_view")
public class EmployeeInfoView {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="emp_code")
	private Integer empCode;
	@Column(name="emp_number")
	private String empNumber;
	@Column(name="emp_name")
	private String empName;
	@Column(name="entered_per")
	private String enteredPer;

}
