package com.onward.hrservice.entity;

import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Data;

@Data
@Entity
@Table(name = "pincode_master")
public class PincodeMaster {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="pin_code")
	private String pinCode;
	@Column(name="pin_pin_code")
	private String pinPincode;
	@Column(name="pin_name")
	private String pinName;
	@Column(name="pin_taluk_name")
	private String pinTalukName;
	@Column(name="pin_district_name")
	private String pinDistrictName;
	@Column(name="pin_state_name")
	private String pinStateName;
	@Column(name="pin_country_name")
	private String pinCountryName;
	@Column(name="status")
	private String status;
	@Column(name="created_by")
	private Integer createdBy;
	@Column(name="created_on")
	private LocalDateTime createdOn;
	@Column(name="modified_by")
	private Integer modifiedBy;
	@Column(name="modified_on")
	private LocalDateTime modifiedOn;
	@Column(name="approved_by")
	private Integer approvedBy;
	@Column(name="approved_on")
	private LocalDateTime approvedOn;

}
