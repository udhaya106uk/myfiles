package com.onward.hrservice.entity;

import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Data;

@Data
@Entity
@Table(name = "emp_visa_det")
public class EmployeeVisaDetails {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="empv_code")
	private Integer empvCode;
	@Column(name="emp_code")
	private Integer empCode;
	@Column(name="empv_visa_type")
	private String empvVisaType;
	@Column(name="empv_visa_doc_no")
	private Integer empvVisaDocNo;
	@Column(name="empv_start_date")
	private LocalDateTime empvStartDate;
	@Column(name="empv_end_date")
	private LocalDateTime empvEndDate;
	@Column(name="status")
	private String status;
	@Column(name="created_by")
	private Integer createdBy;
	@Column(name="created_on")
	private LocalDateTime createdOn;
	@Column(name="modified_by")
	private Integer modifiedBy;
	@Column(name="modified_on")
	private LocalDateTime modifiedOn;
	@Column(name="approved_by")
	private Integer approvedBy;
	@Column(name="approved_on")
	private LocalDateTime approvedOn;

}
