package com.onward.hrservice.entity;

import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Data;

@Entity
@Table(name = "user_master")
@Data
public class UserMaster {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "user_code")
	private Integer userCode;
	@Column(name = "org_code")
	private Integer orgCode;
	@Column(name = "emp_code")
	private Integer empCode;
	@Column(name = "user_name")
	private String userName;
	@Column(name = "user_password")
	private String userPassword;
	@Column(name = "user_created_date")
	private LocalDateTime userCreatedDate;
	@Column(name = "status")
	private String status;
	@Column(name = "created_by")
	private Integer createdBy;
	@Column(name = "created_on")
	private LocalDateTime createdOn;
	@Column(name = "modified_by")
	private Integer modifiedBy;
	@Column(name = "modified_on")
	private LocalDateTime modifiedOn;
	@Column(name = "approved_by")
	private Integer approvedBy;
	@Column(name = "approved_on")
	private LocalDateTime approvedOn;
	@Column(name = "user_pw_expiry_period")
	private Integer userPwExpiryPeriod;
	@Column(name = "user_pw_secret_key")
	private String userPwSecretKey;
	@Column(name = "user_pw_changed_date")
	private LocalDateTime userPwChangedDate;

}