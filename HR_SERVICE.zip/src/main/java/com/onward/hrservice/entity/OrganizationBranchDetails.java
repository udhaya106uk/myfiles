package com.onward.hrservice.entity;

import java.time.LocalDateTime;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Data;

@Data
@Entity
@Table(name = "org_branch_det")
public class OrganizationBranchDetails {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer orgbCode;
	private Integer orgCode;
	private String orgbName;
	private String orgbAddress1;
	private String orgbAddress2;
	private String orgbAddress3;
	private String orgbPincode;
	private String orgbPhoneNumber;
	private String orgbMbileNumber;
	private String orgbFaxNumber;
	private String orgbEmailId;
	private String orgbWebsiteName;
	private LocalDateTime orgbCreationDate;
	private String orgbBusUnitType;
	private String orgbBusUnitSubtype;
	private String orgbBusUnitFunction;
	private String orgb_status;
	private String status;
	private Integer createdBy;
	private LocalDateTime createdOn;
	private Integer modifiedBy;
	private LocalDateTime modifiedOn;
	private Integer approvedBy;
	private LocalDateTime approvedOn;

}
