package com.onward.hrservice.entity;

import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Data;

@Data
@Entity
@Table(name = "emp_passport_det")
public class EmployeePassportDetails {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="empp_code")
	private Integer emppCode;
	@Column(name="emp_code")
	private Integer empCode;
	@Column(name="empp_country")
	private String emppCountry;
	@Column(name="empp_issue_date")
	private LocalDateTime emppIssueDate;
	@Column(name="empp_expiry_date")
	private LocalDateTime emppExpiryDate;
	@Column(name="empp_number")
	private String emppNumber;
	@Column(name="empp_doc_number")
	private Integer emppDocNumber;
	@Column(name="status")
	private String status;
	@Column(name="created_by")
	private Integer createdBy;
	@Column(name="created_on")
	private LocalDateTime createdOn;
	@Column(name="modified_by")
	private Integer modifiedBy;
	@Column(name="modified_on")
	private LocalDateTime modifiedOn;
	@Column(name="approved_by")
	private Integer approvedBy;
	@Column(name="approved_on")
	private LocalDateTime approvedOn;

}
