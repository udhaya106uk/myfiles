package com.onward.hrservice.entity;

import java.time.LocalDateTime;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Data;

@Data
@Entity
@Table(name = "org_master")
public class OrganizationMaster {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer orgCode;
	private String orgNumber;
	private String orgName;
	private String orgShortName;
	private String orgApplicationTitle;
	private String orgSlogan;
	private String orgAddress1;
	private String orgAddress2;
	private String orgAddress3;
	private String orgPincode;
	private String orgPhoneNumber;
	private String orgMbileNumber;
	private String orgFaxNumber;
	private String orgEmailId;
	private String orgWebsiteName;
	private String orgIsinCode;
	private LocalDateTime orgDateOfIncorporation;
	private String orgPanNumber;
	private String orgTinNumber;
	private String orgCinNumber;
	private String orgTanNumber;
	private String orgDinNumber;
	private String orgGstNumber;
	private Integer orgPasswordExpiryPeriod;
	private String orgMaximumInactiveTime;
	private Integer orgLogo;
	private String orgStatus;
	private String status;
	private Integer createdBy;
	private LocalDateTime createdOn;
	private Integer modifiedBy;
	private LocalDateTime modifiedOn;
	private Integer approvedBy;
	private LocalDateTime approvedOn;

}
