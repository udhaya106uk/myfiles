package com.onward.hrservice.entity;

import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Data;

@Data
@Entity
@Table(name = "emp_business_det")
public class EmployeeBusinessDetails {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="empb_code")
	private Integer empbCode;
	@Column(name="emp_code")
	private Integer empCode;
	@Column(name="empb_cost_allocation")
	private String empbCostAllocation;
	@Column(name="empb_cost_entity")
	private String empbCostEntity;
	@Column(name="empb_cost_bus_function")
	private String empbCostBusFunction;
	@Column(name="empb_dep_id")
	private String empbDepId;
	@Column(name="empb_dep_baselocation")
	private String empbDepBaselocation;
	@Column(name="empb_dep_industry")
	private String empbDepIndustry;
	@Column(name="empb_dep_subindustry")
	private String empbDepSubindustry;
	@Column(name="empb_dep_engagement")
	private String empbDepEngagement;
	@Column(name="empb_lob")
	private String empbLob;
	@Column(name="empb_lob_sub")
	private String empbLobSub;
	@Column(name="empb_lob_revenue_cat")
	private String empbLobRevenueCat;
	@Column(name="orgbc_code")
	private Integer orgbcCode;
	@Column(name="emb_tf_depu_date")
	private LocalDateTime embTfDepuDate;
	@Column(name="emb_tf_isintratransfer")
	private String embTfIsintratransfer;
	@Column(name="empb_tf_worklocation")
	private String empbTfWorklocation;
	@Column(name="empb_tf_cost")
	private String empbTfCost;
	@Column(name="empb_tf_state")
	private String empbTfState;
	@Column(name="empb_regional_bu")
	private String empbRegionalBu;
	@Column(name="empb_bu")
	private String empbBu;
	@Column(name="empb_cus_name")
	private String empbCusName;
	@Column(name="empb_cust_code")
	private String empbCustCode;
	@Column(name="empb_pd_code")
	private String empbPdCode;
	@Column(name="empb_cust_country")
	private String empbCustCountry;
	@Column(name="empb_cust_state")
	private String empbCustState;
	@Column(name="emb_tf_depu_end_date")
	private LocalDateTime embTfDepuEndDate;
	@Column(name="status")
	private String status;
	@Column(name="created_by")
	private Integer createdBy;
	@Column(name="created_on")
	private LocalDateTime createdOn;
	@Column(name="modified_by")
	private Integer modifiedBy;
	@Column(name="modified_on")
	private LocalDateTime modifiedOn;
	@Column(name="approved_by")
	private Integer approvedBy;
	@Column(name="approved_on")
	private LocalDateTime approvedOn;

}
