package com.onward.hrservice.entity;

import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Data;

@Data
@Entity
@Table(name = "emp_address_det")
public class EmployeeAddressDetails {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="empa_code")
	private Integer empaCode;
	@Column(name="emp_code")
	private Integer empCode;
	@Column(name="empa_cur_address1")
	private String empaCurAddress1;
	@Column(name="empa_cur_address2")
	private String empaCurAddress2;
	@Column(name="empa_cur_address3")
	private String empaCurAddress3;
	@Column(name="empa_cur_pincode")
	private String empaCurPincode;
	@Column(name="empa_per_address1")
	private String empaPerAddress1;
	@Column(name="empa_per_address2")
	private String empaPerAddress2;
	@Column(name="empa_per_address3")
	private String empaPerAddress3;
	@Column(name="empa_per_pincode")
	private String empaPerPincode;
	@Column(name="status")
	private String status;
	@Column(name="created_by")
	private Integer createdBy;
	@Column(name="created_on")
	private LocalDateTime createdOn;
	@Column(name="modified_by")
	private Integer modifiedBy;
	@Column(name="modified_on")
	private LocalDateTime modifiedOn;
	@Column(name="approved_by")
	private Integer approvedBy;
	@Column(name="approved_on")
	private LocalDateTime approvedOn;

}
