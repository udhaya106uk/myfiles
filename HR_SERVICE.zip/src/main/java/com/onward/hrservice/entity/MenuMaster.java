package com.onward.hrservice.entity;

import java.time.LocalDateTime;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Data;

@Data
@Entity
@Table(name = "menu_master")
public class MenuMaster {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer menuCode;
	private String menuDescription;
	private String menuUrl;
	private Integer menuParentCode;
	private Integer menuLevel;
	private Integer menuDisplayOrder;
	private String menuIsvisible;
	private String status;
	private Integer createdBy;
	private LocalDateTime createdOn;
	private Integer modifiedBy;
	private LocalDateTime modifiedOn;
	private Integer approvedBy;
	private LocalDateTime approvedOn;

}
