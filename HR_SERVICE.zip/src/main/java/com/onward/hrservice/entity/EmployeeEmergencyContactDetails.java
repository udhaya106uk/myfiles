package com.onward.hrservice.entity;

import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Data;

@Data
@Entity
@Table(name = "emp_emerg_contact_det")
public class EmployeeEmergencyContactDetails {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="emgc_code")
	private Integer emgcCode;
	@Column(name="emp_code")
	private Integer empCode;
	@Column(name="emgc_name")
	private String emgcName;
	@Column(name="emgc_relationship")
	private String emgcRelationship;
	@Column(name="emgc_contact_number")
	private String emgcContactNumber;
	@Column(name="emgc_email_id")
	private String emgcEmailId;
	@Column(name="status")
	private String status;
	@Column(name="created_by")
	private Integer createdBy;
	@Column(name="created_on")
	private LocalDateTime createdOn;
	@Column(name="modified_by")
	private Integer modifiedBy;
	@Column(name="modified_on")
	private LocalDateTime modifiedOn;
	@Column(name="approved_by")
	private Integer approvedBy;
	@Column(name="approved_on")
	private LocalDateTime approvedOn;

}
