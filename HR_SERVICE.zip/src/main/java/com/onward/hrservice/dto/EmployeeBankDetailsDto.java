package com.onward.hrservice.dto;

import lombok.Data;

@Data

public class EmployeeBankDetailsDto {

	private Integer embkMnhId;
	private String embkNameAsperBank;
	private String embkBankName;
	private String embkBankAccNo;
	private String embkIfscCode;
}