package com.onward.hrservice.dto;

import lombok.Data;

@Data
public class BusinessDetailsDto {
	
	private String empbCostAllocation;
	private String empbCostEntity;
	private String empbCostBusFunction;
	private String empbDepId;
	private String empbDepName;
	private String empbDepBaselocation;
	private String empbDepIndustry;
	private String empbDepSubindustry;
	private String empbDepEngagement;
	private String empbLob;
	private String empbLobSub;
	private String empbLobRevenueCat;
	private Integer orgbcCode;
	private String embTfDepuDate;
	private String embTfIsintratransfer;
	private String empbTfWorklocation;
	private String empbTfCost;
	private String empbTfState;
	private String empbRegionalBu;
	private String empbBu;
	private String empbCusName;
	private String empbCustCode;
	private String empbPdCode;
	private String empbCustCountry;
	private String empbCustState;
	private String embTfDepuEndDate;

}
