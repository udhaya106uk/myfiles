package com.onward.hrservice.dto;

import lombok.Data;

@Data
public class AddressDetailsDto {
	
	private String empaCurAddress1;
	private String empaCurAddress2;
	private String empaCurAddress3;
	private String empaCurPincode;
	private String empaPerAddress1;
	private String empaPerAddress2;
	private String empaPerAddress3;
	private String empaPerPincode;

}
