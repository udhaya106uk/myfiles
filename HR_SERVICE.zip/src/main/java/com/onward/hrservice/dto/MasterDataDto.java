package com.onward.hrservice.dto;

import lombok.Data;

@Data
public class MasterDataDto {
	
	private String code;
	private String description;

}
