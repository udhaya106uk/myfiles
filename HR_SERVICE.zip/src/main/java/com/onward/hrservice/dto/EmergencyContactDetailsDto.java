package com.onward.hrservice.dto;

import lombok.Data;

@Data
public class EmergencyContactDetailsDto {
	
	private String emgcName;
	private String emgcRelationship;
	private String emgcContactNumber;

}
