package com.onward.hrservice.dto;

import java.util.List;

import lombok.Data;

@Data
public class EmployeeDetailsDto {
	
	private String employeeId;
	private String empNumber;
	private String empName;
	private String dropDownCode;
	private String customerName;
	private List<Integer> employeeCodes;
	private String fromDate;
	private String toDate;
}
