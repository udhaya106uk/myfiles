package com.onward.hrservice.dto;

import lombok.Data;

@Data
public class EmployeeDashboardDto {
	
	private String employeeCode;
	private String employeeName;
	private String employeeDesignation;
	private String hrbp;
	private String customer;
	private String reportingManager;
	private String grade;
	private String category;
	private String profileCompletion;
	private String employeeImage;
	private String employeeId;
	private String empDob;

}
