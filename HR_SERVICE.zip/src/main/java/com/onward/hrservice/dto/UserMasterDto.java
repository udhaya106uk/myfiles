package com.onward.hrservice.dto;

import lombok.Data;

@Data
public class UserMasterDto {

	private Integer empCode;
	private String firstName;
	private String lastName;
	private String userPassword;
	private String userEmail;
	private String validationCode;

}
