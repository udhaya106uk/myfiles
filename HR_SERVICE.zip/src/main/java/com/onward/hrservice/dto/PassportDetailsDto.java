package com.onward.hrservice.dto;

import lombok.Data;

@Data
public class PassportDetailsDto {
	
	private String emppNumber;
	private String emppCountry;
	private String emppIssueDate;
	private String emppExpiryDate;
	private String empPassportfileName;
	private byte[] empPassportAttachment;

}
