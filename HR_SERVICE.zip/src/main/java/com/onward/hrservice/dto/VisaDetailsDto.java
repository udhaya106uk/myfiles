package com.onward.hrservice.dto;

import lombok.Data;

@Data
public class VisaDetailsDto {
	
	private String empvVisaType;
	private String empvStartDate;
	private String empvEndDate;

}
