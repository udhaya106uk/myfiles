package com.onward.hrservice.dto;

import lombok.Data;

@Data
public class BasicDetailsDto {
	
	private String empNumber;
	private String empName;
	private String empGender;
	private String empDob;
	private String empBloodGroup;
	private String empMaritalStatus;
	private String empFatherOrHusbandName;
	private String empPersonalEmailId;
	private String empPrimContactNo;
	private String empSecContactNo;
	private String empDoj;
	private String empInitialDoj;
	private String empConformationDt;
	private String empConformationStatus;
	private String empNoticePeriod;
	private String empBondApplicable;
	private Integer empAmountOfBond;
	private String empBondStartDate;
	private String empBondEndDate;
	private String empActStartDate;
	private String empActdEndDate;
	private String empResDate;
	private String empTenLwd;
	private String empLwd;
	private String empLwdMonth;
	private String empState;
	private String empReason;
	private String empGratFormula;
	private String empFnf;
	private String empPreviousExp;
	private String empRelevantExpBj;
	private String empOtlExp;
	private String empInitialOtlExp;
	private String empTotalExp;
	private String empSkillSet;
	private String empPanNumber;
	private String empAadharNumber;
	private String empEpfNumber;
	private String empUanNumber;
	private String empEsicNumber;
	private String empRmid;
	private String empHrbpid;
	private String empCategory;
	private String empGrade;
	private String empDesignation;
	private String empStatus;
	private String empRepManager;
	private Integer empAge;
	private String empQualification;
	private String empSpecial;
	private String empCertification;
	private String image;
	private String profileCompletion;
	private String empAadharfileName;
	private String empPanfileName;
	private String empDeputationApplicable;
	private byte[] empAadharAttachment;
	private byte[] empPanAttachment;
	private String empEmailAddress;
	private Integer orgbCode;
	private String employeeId;
	private String empSeparationType;

}
